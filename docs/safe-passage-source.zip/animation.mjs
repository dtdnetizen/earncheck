// SAFE PASSAGE — original vector adaptation of the toy-drone scene in Snowmoon ch. 1.
// GPL-3.0-only. Every frame is generated from time; no external assets.
export const WIDTH=1920, HEIGHT=1080, FPS=24, DURATION=36;
const C={sky:'#E8E9CB',cream:'#F5EBCD',sun:'#EBCB7D',moss:'#34574A',pine:'#244638',leaf:'#688262',light:'#AFC096',stone:'#BBB79F',line:'#858D76',plum:'#3C2947',plum2:'#594264',skin:'#BA865D',gold:'#C89149',ink:'#263B34',green:'#77C875',white:'#FFF9E9'};
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const ease=x=>{x=clamp(x);return x*x*(3-2*x)};
const mix=(a,b,t)=>a+(b-a)*t;
const f=n=>Number(n).toFixed(2);
const R=(x,y,w,h,fill,rx=0,extra='')=>`<rect x="${f(x)}" y="${f(y)}" width="${f(w)}" height="${f(h)}" rx="${rx}" fill="${fill}" ${extra}/>`;
const E=(x,y,rx,ry,fill,extra='')=>`<ellipse cx="${f(x)}" cy="${f(y)}" rx="${f(rx)}" ry="${f(ry)}" fill="${fill}" ${extra}/>`;
const P=(d,fill,extra='')=>`<path d="${d}" fill="${fill}" ${extra}/>`;
const L=(d,color,width,extra='')=>P(d,'none',`stroke="${color}" stroke-width="${width}" stroke-linecap="round" stroke-linejoin="round" ${extra}`);
const T=(x,y,s,size,fill=C.ink,weight=600,extra='')=>`<text x="${x}" y="${y}" fill="${fill}" font-family="Arial, sans-serif" font-size="${size}" font-weight="${weight}" ${extra}>${s}</text>`;
const defs=`<defs>
 <linearGradient id="sky" x2="0" y2="1"><stop stop-color="#CFDAC0"/><stop offset="1" stop-color="${C.sky}"/></linearGradient>
 <linearGradient id="path" x2="0" y2="1"><stop stop-color="#D8D5BA"/><stop offset="1" stop-color="#ABA98F"/></linearGradient>
 <linearGradient id="robe" x2="0.15" y2="1"><stop stop-color="${C.plum2}"/><stop offset="1" stop-color="${C.plum}"/></linearGradient>
 <radialGradient id="sun"><stop stop-color="#FFF9DB" stop-opacity=".96"/><stop offset="1" stop-color="#FFF1B5" stop-opacity="0"/></radialGradient>
 <pattern id="grain" width="71" height="71" patternUnits="userSpaceOnUse"><circle cx="7" cy="11" r="1.2" fill="#4D5944" opacity=".13"/><circle cx="42" cy="36" r="1" fill="#4D5944" opacity=".12"/><circle cx="58" cy="63" r="1" fill="#4D5944" opacity=".11"/></pattern>
 <clipPath id="screen"><rect x="0" y="0" width="1920" height="1080"/></clipPath>
 </defs>`;
function tree(x,y,s,phase=0){
 const sway=Math.sin(phase)*5*s;
 return `<g transform="translate(${f(x)},${f(y)}) scale(${f(s)})">`+
 E(5,6,154,28,'#314F3F','opacity=".23"')+
 L(`M 0 0 Q -7 -220 ${f(sway)} -506`,C.ink,46)+
 L(`M -8 -175 Q -94 -270 -158 -290 M -4 -237 Q 74 -315 137 -365`,C.ink,18)+
 E(-127+sway,-392,140,120,C.pine)+E(18+sway,-518,185,160,C.moss)+E(135+sway,-377,128,115,C.leaf)+
 E(-95+sway,-474,86,74,C.light,'opacity=".75"')+E(79+sway,-568,90,55,C.light,'opacity=".55"')+
 P('M -162 -460 Q -95 -572 16 -558 Q -66 -492 -162 -460',C.leaf,'opacity=".65"')+
 `</g>`;
}
function landscape(t,scale=1,shift=0){
 let s=R(0,0,1920,1080,'url(#sky)')+E(1530,160,540,510,'url(#sun)')+E(1525,168,103,103,C.sun,'opacity=".62"');
 s+=P('M 0 536 Q 280 448 530 501 T 1020 477 T 1920 478 V 750 H 0 Z','#849C77');
 s+=P('M 0 601 Q 360 535 632 584 T 1270 547 T 1920 600 V 790 H 0 Z','#668368');
 // Main brick path and visible branch to the left: stable geography in all wides.
 s+=P('M 883 582 L 1066 582 L 1690 1080 L 430 1080 Z','url(#path)');
 s+=P('M 925 626 Q 693 633 462 705 L 0 784 L 0 983 Q 416 813 827 743 Z','#CBC8AD');
 s+=L('M 884 584 L 431 1080 M 1066 584 L 1690 1080',C.line,7,'opacity=".55"');
 for(let row=0;row<9;row++){
  const q=row/9,y=602+q*q*495,w=105+q*630,x=975;
  s+=L(`M ${f(x-w)} ${f(y)} Q ${x} ${f(y+8*q)} ${f(x+w)} ${f(y)}`,C.line,3+q*3,'opacity=".55"');
  for(let j=-2;j<=2;j++){const xx=x+j*54*(1+q*4)+(row%2?26:0);s+=L(`M ${f(xx)} ${f(y)} l ${f(-10*q)} ${f(19+q*31)}`,C.line,2+q*2,'opacity=".35"');}
 }
 for(let j=0;j<7;j++){let y=656+j*36,x=820-j*127; s+=L(`M ${f(x)} ${f(y)} l ${f(-100-j*21)} ${f(25+j*5)}`,C.line,2.5,'opacity=".38"');}
 // Distant trunks, near trees, then foreground canopy for layered depth.
 for(let i=0;i<12;i++){const x=i*182-45; s+=tree(x,715,.31+(i%3)*.05,t*.24+i);}
 s+=tree(33,955,1.18,t*.2)+tree(1835,1010,1.34,t*.17+1)+tree(475,797,.55,t*.2+3)+tree(1480,804,.58,t*.2+4);
 s+=P('M 0 0 Q 240 82 383 10 L 475 0 Z',C.pine,'opacity=".73"')+P('M 1630 0 Q 1722 121 1920 69 V 0 Z',C.moss,'opacity=".8"');
 for(let i=0;i<14;i++){const x=((i*383)%1880)+20,y=610+(i*47)%270; s+=E(x+Math.sin(t*.7+i)*15,y+Math.cos(t*.5+i)*10,8,3,C.sun,`transform="rotate(${(i*57)%360} ${x} ${y})" opacity=".53"`);}
 return `<g transform="translate(${f(shift)},0) scale(${f(scale)})">${s}</g>`;
}
function gladias(x,ground,scale=1,walk=0,pose=0){
 const bob=Math.abs(Math.sin(walk))*9*scale, stride=Math.sin(walk)*29*scale;
 const y=ground-bob, S=scale;
 let s=E(x,y+8,114*S,24*S,C.ink,'opacity=".23"');
 s+=L(`M ${f(x-29*S)} ${f(y-86*S)} L ${f(x-40*S+stride)} ${f(y+2*S)} M ${f(x+31*S)} ${f(y-86*S)} L ${f(x+37*S-stride)} ${f(y+2*S)}`,C.plum,31*S);
 s+=E(x-40*S+stride,y+1*S,31*S,10*S,C.ink)+E(x+37*S-stride,y+1*S,31*S,10*S,C.ink);
 s+=P(`M ${f(x-103*S)} ${f(y-310*S)} Q ${f(x-82*S)} ${f(y-390*S)} ${f(x+20*S)} ${f(y-380*S)} Q ${f(x+112*S)} ${f(y-325*S)} ${f(x+98*S)} ${f(y-150*S)} L ${f(x+129*S)} ${f(y-46*S)} Q ${f(x)} ${f(y-11*S)} ${f(x-113*S)} ${f(y-43*S)} L ${f(x-94*S)} ${f(y-153*S)} Z`,'url(#robe)',`stroke="${C.ink}" stroke-width="${7*S}"`);
 s+=P(`M ${f(x-97*S)} ${f(y-331*S)} Q ${f(x-87*S)} ${f(y-449*S)} ${f(x+11*S)} ${f(y-459*S)} Q ${f(x+111*S)} ${f(y-442*S)} ${f(x+105*S)} ${f(y-329*S)} Q ${f(x+56*S)} ${f(y-299*S)} ${f(x-97*S)} ${f(y-331*S)}`,C.plum,`stroke="${C.ink}" stroke-width="${7*S}"`);
 s+=E(x+9*S,y-368*S,61*S,71*S,'#251E30')+P(`M ${f(x-51*S)} ${f(y-394*S)} Q ${f(x+20*S)} ${f(y-461*S)} ${f(x+76*S)} ${f(y-393*S)} Q ${f(x+4*S)} ${f(y-419*S)} ${f(x-51*S)} ${f(y-394*S)}`,C.plum2);
 const armLift=pose*54*S;
 s+=L(`M ${f(x+73*S)} ${f(y-282*S)} Q ${f(x+128*S)} ${f(y-232*S)} ${f(x+125*S)} ${f(y-194*S-armLift)}`,C.plum,48*S);
 s+=E(x+126*S,y-193*S-armLift,23*S,25*S,C.skin);
 s+=R(x+109*S,y-210*S-armLift,35*S,12*S,C.ink,4);
 s+=L(`M ${f(x-75*S)} ${f(y-287*S)} Q ${f(x-129*S)} ${f(y-212*S)} ${f(x-100*S)} ${f(y-176*S)}`,C.plum,45*S);
 return s;
}
function drone(x,y,scale=1,spin=0){
 const S=scale;
 let s=E(x,y+139*S,124*S,19*S,C.ink,'opacity=".12"');
 s+=`<g transform="translate(${f(x)},${f(y)}) scale(${f(S)})">`;
 // Precisely three featherlike side rotor clusters, spaced 120 degrees.
 for(let k=0;k<3;k++){
  const a=-Math.PI/2+k*2*Math.PI/3,px=Math.cos(a)*82,py=Math.sin(a)*82;
  s+=L(`M ${f(Math.cos(a)*43)} ${f(Math.sin(a)*43)} L ${f(px)} ${f(py)}`,C.ink,9);
  s+=`<g transform="translate(${f(px)},${f(py)}) rotate(${f(a*180/Math.PI+90+Math.sin(spin*13+k)*9)})">`;
  s+=P('M 0 -7 Q -22 -46 -68 -47 Q -44 -17 -6 0 Z',C.white,`stroke="${C.ink}" stroke-width="4"`);
  s+=P('M 0 -7 Q 22 -46 68 -47 Q 44 -17 6 0 Z',C.cream,`stroke="${C.ink}" stroke-width="4"`);
  s+=L('M -52 -39 L -12 -11 M 52 -39 L 12 -11',C.line,3,'opacity=".75"');
  s+='</g>';
 }
 s+=E(0,0,49,49,C.white,`stroke="${C.ink}" stroke-width="7"`)+E(0,0,32,32,C.gold)+E(0,0,14,14,C.ink)+E(-10,-11,7,5,C.white,'opacity=".85"');
 return s+'</g>';
}
function boy(x,ground,scale=1,jump=0,arms=0,held=false){
 const S=scale, y=ground-jump*S;
 let s=E(x,ground+10*S,82*S,17*S,C.ink,'opacity=".22"');
 s+=L(`M ${f(x-15*S)} ${f(y-107*S)} L ${f(x-51*S)} ${f(y-12*S)} M ${f(x+18*S)} ${f(y-107*S)} L ${f(x+52*S)} ${f(y-12*S)}`,C.ink,27*S);
 s+=E(x-53*S,y-7*S,33*S,13*S,C.plum)+E(x+54*S,y-7*S,33*S,13*S,C.plum);
 s+=P(`M ${f(x-62*S)} ${f(y-246*S)} Q ${f(x+3*S)} ${f(y-272*S)} ${f(x+64*S)} ${f(y-241*S)} L ${f(x+41*S)} ${f(y-104*S)} L ${f(x-48*S)} ${f(y-104*S)} Z`,C.sun,`stroke="${C.ink}" stroke-width="6"`);
 s+=E(x,y-304*S,55*S,59*S,C.skin,`stroke="${C.ink}" stroke-width="6"`);
 s+=P(`M ${f(x-59*S)} ${f(y-315*S)} Q ${f(x-49*S)} ${f(y-380*S)} ${f(x+28*S)} ${f(y-365*S)} Q ${f(x+60*S)} ${f(y-344*S)} ${f(x+60*S)} ${f(y-307*S)} Q ${f(x+13*S)} ${f(y-341*S)} ${f(x-59*S)} ${f(y-315*S)}`,C.ink);
 s+=E(x+21*S,y-305*S,4*S,5*S,C.ink)+L(`M ${f(x+11*S)} ${f(y-277*S)} Q ${f(x+26*S)} ${f(y-266*S)} ${f(x+40*S)} ${f(y-279*S)}`,C.ink,3.5*S);
 const hy=y-(arms?390:180)*S;
 const leftX=x+(arms?-18:-45)*S, handX=x+(held?42:arms?42:76)*S;
 s+=L(`M ${f(x-48*S)} ${f(y-225*S)} Q ${f(x-104*S)} ${f(y-265*S)} ${f(leftX)} ${f(hy)}`,C.skin,18*S);
 s+=L(`M ${f(x+46*S)} ${f(y-225*S)} Q ${f(x+106*S)} ${f(y-270*S)} ${f(handX)} ${f(hy)}`,C.skin,18*S);
 s+=E(leftX,hy,13*S,17*S,C.skin)+E(handX,hy,13*S,17*S,C.skin);
 return s;
}
function shot1(t){
 const u=clamp(t/8), x=510+u*430, bob=Math.sin(t*9)*3;
 let s=landscape(t)+E(854,970,427,60,C.ink,'opacity=".09"');
 s+=gladias(x,1001+bob,.91,t*7,0);
 // Overhead arrival is deliberately late and spatially distant.
 if(t>4.6)s+=drone(1410-(t-4.6)*71,205+Math.sin(t*4)*11,.69,t);
 s+=T(72,103,'MELDAN · VERIDIA',30,C.cream,700,'letter-spacing="5" opacity=".94"');
 return s;
}
function shot2(t){
 const u=clamp((t-8)/5), j=ease((u-.3)/.42);
 let s=landscape(t,1.13,-215)+E(950,1000,480,73,C.ink,'opacity=".11"');
 s+=gladias(655,1081,1.33,0,j*.9);
 s+=drone(1290-u*184,310+Math.sin(t*7)*15,1.23,t);
 s+=P(`M 1030 352 Q 1010 295 1023 260`, 'none',`stroke="${C.cream}" stroke-width="4" opacity="${f(.45+u*.4)}"`);
 return s;
}
function shot3(t){
 const u=clamp((t-13)/6),on=ease((u-.11)/.18),row2=ease((u-.35)/.18);
 let s=R(0,0,1920,1080,C.pine)+E(1400,250,650,540,'#466957','opacity=".58"');
 // Abstract private-data blocks; no operator identity is presented.
 for(let i=0;i<7;i++) s+=R(90+(i%3)*207,105+Math.floor(i/3)*129,136,37,C.light,8,`opacity="${f(.12+i*.02)}"`);
 s+=P('M 0 920 Q 317 746 650 674 L 775 850 L 1920 1080 H 0 Z','url(#robe)');
 s+=L('M 0 920 Q 317 746 650 674 L 775 850',C.plum2,18);
 s+=P('M 455 756 Q 601 514 867 488 Q 1195 513 1339 727 L 1152 1090 H 626 Z',C.plum,`stroke="${C.ink}" stroke-width="16"`);
 s+=E(997,648,390,330,C.ink)+E(997,648,337,285,C.white)+E(997,648,309,258,'#2D554A');
 s+=R(724,465,545,363,'#23483D',35,`stroke="${C.light}" stroke-width="5"`);
 s+=R(758,503,476,129,C.green,19,`opacity="${f(on)}"`);
 s+=E(811,567,31,31,C.white,`opacity="${f(on)}"`)+L('M 797 568 l 11 12 l 23 -30',C.pine,9,`opacity="${f(on)}"`);
 s+=T(867,585,'TOY VERIFIED',49,C.pine,800,`opacity="${f(on)}" letter-spacing="2"`);
 s+=R(758,656,476,129,C.green,19,`opacity="${f(row2)}"`);
 s+=E(811,721,31,31,C.white,`opacity="${f(row2)}"`)+L('M 797 721 l 11 12 l 23 -30',C.pine,9,`opacity="${f(row2)}"`);
 s+=T(867,738,'SAFE ROUTE',49,C.pine,800,`opacity="${f(row2)}" letter-spacing="2"`);
 // Empty slits communicate withheld details, without claiming they were read.
 s+=R(1342,507,300,36,C.light,10,'opacity=".26"')+R(1342,568,235,36,C.light,10,'opacity=".22"')+R(1342,629,270,36,C.light,10,'opacity=".17"');
 s+=P('M 1571 723 l 77 34 v 72 q -18 59 -77 89 q -58 -30 -77 -89 v -72 Z',C.cream,'opacity=".78"');
 s+=R(1538,783,67,33,C.pine,7)+P('M 1544 782 v -18 q 0 -28 27 -28 t 27 28 v 18','none',`stroke="${C.pine}" stroke-width="13"`);
 return s;
}
function shot4(t){
 const u=clamp((t-19)/8),catchT=.62,flight=ease(u/catchT),after=u>=catchT;
 const by=899,bx=566;
 const jump=130*Math.sin(Math.PI*clamp((u-.18)/.57));
 const jumpAtCatch=130*Math.sin(Math.PI*clamp((catchT-.18)/.57));
 const heldX=bx+12,heldY=by-jump*1.02-390*1.02-20;
 const catchY=by-jumpAtCatch*1.02-390*1.02-20;
 const dx=mix(1310,heldX,flight),dy=mix(224,catchY,flight);
 let s=landscape(t,1.06,-118);
 s+=boy(bx,by,1.02,jump,u>.15?1:0,after);
 // Until catch, ball is airborne. At contact it locks to the raised hands.
 if(!after){s+=drone(dx,dy,.54,t);s+=L(`M ${f(dx+110)} ${f(dy-12)} q 73 -34 138 -13`,C.cream,5,'opacity=".67"');}
 else {s+=drone(heldX,heldY,.54,19+8*catchT);}
 if(after){const glow=ease((u-catchT)/.16);s+=P(`M ${bx-117} ${by-530} l -26 -31 M ${bx+145} ${by-525} l 29 -37 M ${bx+4} ${by-590} v -43`,'none',`stroke="${C.sun}" stroke-width="9" stroke-linecap="round" opacity="${f(glow)}"`);}
 return s;
}
function shot5(t){
 const u=clamp((t-27)/9), walk=ease(u), fade=ease((u-.63)/.19);
 let s=landscape(t)+boy(414,918,.64,0,1,true)+drone(421,655,.36,t);
 s+=gladias(854+walk*450,1031,.94,t*7,0);
 s+=R(0,0,1920,1080,C.pine,0,`opacity="${f(fade*.72)}"`);
 s+=T(105,263,'SAFE PASSAGE',118,C.white,800,`letter-spacing="10" opacity="${f(fade)}"`);
 s+=L('M 110 303 H 815',C.sun,9,`opacity="${f(fade)}"`);
 s+=T(111,370,'A SMALL MOMENT IN MELDAN',34,C.cream,600,`letter-spacing="5" opacity="${f(fade)}"`);
 s+=T(108,1009,'After Snowmoon, chapter 1 · story by Vitalik Buterin · adaptation GPL-3.0',26,C.white,500,`opacity="${f(fade)}"`);
 return s;
}
export function frameSvg(t){
 t=clamp(t,0,DURATION);
 let s=t<8?shot1(t):t<13?shot2(t):t<19?shot3(t):t<27?shot4(t):shot5(t);
 return `<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080">${defs}<g clip-path="url(#screen)">${s}${R(0,0,1920,1080,'url(#grain)')}</g></svg>`;
}
