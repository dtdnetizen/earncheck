# License and attribution notice

SPDX-License-Identifier: GPL-3.0-only

*Safe Passage* (animation, vector art, soundtrack generation code, and rendered audiovisual output) is an adaptation of *Snowmoon*, chapter 1, by Vitalik Buterin, available at <https://vitalik.eth.limo/snowmoon/html/chapter-1.html>. The original narrative is licensed under the GNU General Public License version 3. This adaptation is licensed under the GNU General Public License version 3.

Copyright (c) 2026 the *Safe Passage* adaptation contributors.

You may redistribute and modify this work under GPL-3.0-only. The complete corresponding source is the JavaScript in this directory; video and images are generated outputs. License terms: <https://www.gnu.org/licenses/gpl-3.0.html>.

This is an independent adaptation. Credit to Vitalik Buterin identifies the source story and does not imply his endorsement.
