# Safe Passage

A 36-second, 1920 × 1080, 24 fps animated audiovisual reinterpretation of the toy-drone moment in chapter 1 of *Snowmoon*. This is a locally rendered contest candidate, not a submitted entry or a live service.

## Files

- `animation.mjs`: deterministic, time-addressable SVG frames; all shapes and scenery are original vector art.
- `audio.mjs`: deterministic 48 kHz stereo WAV synthesis from oscillators and seeded noise. No external audio clips, voices, samples, or music.
- `render.mjs`: rasterizes SVG frames with Sharp, combines them with the generated soundtrack using FFmpeg.
- `safe-passage-36s.mp4`: generated final H.264/AAC deliverable; it may be distributed separately from a source archive.
- `thumbnail.png`, `contact-sheet.png`, and `catch-continuity.png`: generated still review images.
- `soundtrack.wav`: generated soundtrack before AAC encoding; it may be omitted from a source archive because `audio.mjs` regenerates it.
- `SCRIPT.md`: shot-by-shot story and design notes.
- `PROMPT-HISTORY.md`: brief and implementation decision history.
- `COPYING-NOTICE.md` and `COPYING`: license and attribution, including the full GPLv3 text.

## Rebuild

Install or provide local Node.js, Sharp, and FFmpeg. Set `CODEX_NODE_MODULES` to the `node_modules` directory containing `sharp`, and `FFMPEG_PATH` to an FFmpeg executable if it is not on `PATH`.

```powershell
$env:CODEX_NODE_MODULES = 'path-to-node_modules'
$env:FFMPEG_PATH = 'path-to-ffmpeg'
node .\render.mjs --preview  # contact sheet and thumbnail only
node .\render.mjs            # full deterministic audiovisual render
```

The source has no network calls, credential reads, random inputs, or external media assets. `--preview` takes several seconds; the full 864-frame render takes longer depending on the machine. Output files are overwritten only within this directory. Visual frames and audio are deterministic given the source; MP4 bytes can vary with FFmpeg build and encoder version.

## Story fidelity

The watch confirms only that the drone is a toy and its route is safe. The adjacent obscured blocks represent information withheld from Gladias. The boy voluntarily catches the same three-rotor ball drone; there is no remote operator reveal or claim of ownership. Gladias returns to walking. This piece does not reproduce chapter prose or dialogue.

## Source and license

Adapted from *Snowmoon*, chapter 1, by Vitalik Buterin: <https://vitalik.eth.limo/snowmoon/html/chapter-1.html>. The source story is GPLv3. This reinterpretation, source code, vector art, and generated audio are licensed GPL-3.0-only. See `COPYING-NOTICE.md`. Attribution does not imply author endorsement.
