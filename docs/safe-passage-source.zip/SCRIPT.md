# Script and storyboard

**Format:** 36 seconds, 24 fps, 1920 × 1080, cinematic cut-paper and screenprint treatment. A fixed cream-stone path branches left beneath moss-green trees. Plum and warm sun-yellow anchor the characters. The ball drone has exactly three featherlike rotor assemblies in every shot.

| Time | Shot | Action and sound |
| --- | --- | --- |
| 0–8 s | Establishing wide | Gladias walks beneath trees on the clean stone-brick path in Meldan, Veridia. Layered canopy, subtle leaves and bird chirps. The distant drone comes into view. Quiet footfalls. |
| 8–13 s | Surprise | Tighter view. Drone approaches overhead, rotors flutter. Gladias checks his wrist. A low synthetic whirr enters; the shift is quick but gentle. |
| 13–19 s | Watch close-up | Watch shows only two green confirmations: “TOY VERIFIED” and “SAFE ROUTE.” Separate masked shapes suggest private data not revealed. Two spare confirmation chimes. |
| 19–27 s | Joyful catch | The ball turns down the left branch. A boy leaps, hands meet the ball, then he holds that same three-rotor drone above his head. Catch chime, returning birds. |
| 27–36 s | Return to calm | Boy stays at the branch with the ball; Gladias relaxes and continues his walk along the main path. Scene darkens under the title “SAFE PASSAGE,” followed by source credit and license. Ambient leaves and a restrained two-note ending. |

No dialogue or narrator is used. The watch communicates a narrow safety result, never an identity or location history. The exact catch is locked geometrically in code so the hands touch the ball instead of merely gesturing near it.
