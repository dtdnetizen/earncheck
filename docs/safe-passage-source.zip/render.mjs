// Local-only SVG frame rasterization and H.264/AAC composition.
// Set CODEX_NODE_MODULES to a module directory containing sharp and FFMPEG_PATH
// to an FFmpeg executable. No machine-specific paths are committed here.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {frameSvg,WIDTH,HEIGHT,FPS,DURATION} from './animation.mjs';
import {writeAudio} from './audio.mjs';
const here=path.dirname(fileURLToPath(import.meta.url));
const require=createRequire(import.meta.url);
const moduleRoot=process.env.CODEX_NODE_MODULES;
const sharp=moduleRoot?require(path.join(moduleRoot,'sharp')):require('sharp');
const ffmpeg=process.env.FFMPEG_PATH||'ffmpeg';
const previewOnly=process.argv.includes('--preview');
async function png(t,w=WIDTH,h=HEIGHT){return sharp(Buffer.from(frameSvg(t))).resize(w,h).png().toBuffer();}
const catchTimes=[23.90,23.96,24.02];
const catchComps=[];
for(let i=0;i<catchTimes.length;i++){
 const frame=await sharp(Buffer.from(frameSvg(catchTimes[i]))).extract({left:300,top:180,width:1100,height:680}).resize(550,340).png().toBuffer();
 catchComps.push({input:frame,left:16+i*566,top:45});
}
let catchLabels=`<svg xmlns="http://www.w3.org/2000/svg" width="1714" height="401"><text x="16" y="31" fill="#FFF9E9" font-family="Arial" font-size="22" font-weight="700">CATCH CONTINUITY  /  BEFORE  ·  CONTACT  ·  AFTER</text>`;
catchTimes.forEach((v,i)=>catchLabels+=`<text x="${16+i*566+470}" y="70" fill="#FFF9E9" font-family="Arial" font-size="19" font-weight="700">${v.toFixed(2)}s</text>`);
catchLabels+='</svg>';
await fs.writeFile(path.join(here,'catch-continuity.png'),await sharp({create:{width:1714,height:401,channels:4,background:'#263B34'}}).composite([...catchComps,{input:Buffer.from(catchLabels),left:0,top:0}]).png().toBuffer());
const times=[2.1,6.3,10.4,14.1,17.2,20.7,24.5,29.4,34.4];
const W=480,H=270,M=16,TOP=57;
const overlays=[];
for(let i=0;i<times.length;i++){
 const x=M+(i%3)*(W+M),y=TOP+M+Math.floor(i/3)*(H+M);
 overlays.push({input:await png(times[i],W,H),left:x,top:y});
}
const sw=3*W+4*M,sh=3*H+4*M+TOP;
let labels=`<svg xmlns="http://www.w3.org/2000/svg" width="${sw}" height="${sh}"><text x="16" y="39" fill="#FFF9E9" font-family="Arial" font-size="25" font-weight="700">SAFE PASSAGE  /  36s  /  24fps  /  CONTACT SHEET</text>`;
times.forEach((t,i)=>{const x=M+(i%3)*(W+M)+W-72,y=TOP+M+Math.floor(i/3)*(H+M)+28;labels+=`<rect x="${x-6}" y="${y-22}" width="67" height="29" rx="4" fill="#263B34"/><text x="${x}" y="${y}" fill="#FFF9E9" font-family="Arial" font-size="18">${t.toFixed(1)}s</text>`;});
labels+='</svg>';
await fs.writeFile(path.join(here,'contact-sheet.png'),await sharp({create:{width:sw,height:sh,channels:4,background:'#263B34'}}).composite([...overlays,{input:Buffer.from(labels),left:0,top:0}]).png().toBuffer());
await fs.writeFile(path.join(here,'thumbnail.png'),await png(24.55));
console.log('Contact sheet, catch continuity, and thumbnail generated.');
if(previewOnly)process.exit(0);
const wav=path.join(here,'soundtrack.wav');
console.log('Synthesizing stereo soundtrack…',await writeAudio(wav));
const out=path.join(here,'safe-passage-36s.mp4');
await new Promise(async(resolve,reject)=>{
 const args=['-y','-hide_banner','-loglevel','error','-f','image2pipe','-vcodec','png','-r',String(FPS),'-i','-','-i',wav,'-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-ar','48000','-ac','2','-t',String(DURATION),'-movflags','+faststart',out];
 const p=spawn(ffmpeg,args,{stdio:['pipe','ignore','pipe']});let err='';p.stderr.on('data',x=>err+=x.toString());p.on('error',reject);p.on('exit',code=>code===0?resolve():reject(new Error(`FFmpeg ${code}: ${err}`)));
 try{for(let i=0;i<DURATION*FPS;i++){const image=await png(i/FPS);if(!p.stdin.write(image))await new Promise(r=>p.stdin.once('drain',r));if(i%48===0)console.log(`Rendered ${i}/${DURATION*FPS} frames`);}p.stdin.end();}
 catch(e){p.stdin.destroy();reject(e);}
});
for(const n of ['animation.mjs','audio.mjs','render.mjs','soundtrack.wav','safe-passage-36s.mp4','thumbnail.png','contact-sheet.png','catch-continuity.png']){
 const b=await fs.readFile(path.join(here,n));console.log(`${n}\t${b.length} bytes\tSHA256 ${createHash('sha256').update(b).digest('hex')}`);
}
