// Procedural stereo soundtrack, generated locally without samples or borrowed music.
// GPL-3.0-only.
import fs from 'node:fs/promises';
const SR=48000, SECONDS=36;
const TAU=Math.PI*2;
const env=(t,a,b)=>Math.max(0,Math.min(1,(t-a)/.06,(b-t)/.12));
const chirp=(t,at,pitch)=>{const d=t-at;if(d<0||d>.21)return 0;const w=Math.sin(Math.PI*d/.21)**2;return Math.sin(TAU*(pitch*d+280*d*d))*w;};
const bell=(t,at,pitch)=>{const d=t-at;if(d<0||d>2.2)return 0;const e=Math.exp(-d*4.1);return (Math.sin(TAU*pitch*d)+.27*Math.sin(TAU*pitch*2.02*d))*e;};
const beat=(t,at)=>{const d=t-at;if(d<0||d>.16)return 0;return Math.sin(TAU*(84*d-60*d*d))*Math.exp(-d*28);};
export async function writeAudio(file){
 const n=SR*SECONDS, bytes=44+n*4, buf=Buffer.allocUnsafe(bytes);
 buf.write('RIFF',0);buf.writeUInt32LE(bytes-8,4);buf.write('WAVE',8);buf.write('fmt ',12);buf.writeUInt32LE(16,16);buf.writeUInt16LE(1,20);buf.writeUInt16LE(2,22);buf.writeUInt32LE(SR,24);buf.writeUInt32LE(SR*4,28);buf.writeUInt16LE(4,32);buf.writeUInt16LE(16,34);buf.write('data',36);buf.writeUInt32LE(n*4,40);
 let seed=0x534e4f57,low=0;
 for(let i=0;i<n;i++){
  const t=i/SR;seed=(Math.imul(seed,1664525)+1013904223)>>>0;
  const noise=(seed/4294967295)*2-1; low=low*.996+noise*.004;
  const bed=.075*Math.sin(TAU*110*t)+.04*Math.sin(TAU*165*t)+.025*Math.sin(TAU*220*t);
  const wind=(low*1.3+noise*.025)*(.24+.06*Math.sin(t*.4));
  const leaves=(noise*.045+low*.36)*(1+.3*Math.sin(t*1.4));
  let birds=0;
  for(const at of [1.1,1.34,3.5,3.78,6.3,7.2,20.1,26.1,29.4,33.1]) birds+=chirp(t,at,980+at*11)*.18;
  let drone=0;if(t>5&&t<25.1){const d=env(t,5,25.1);drone=d*(.062*Math.sin(TAU*(134+2*Math.sin(t*2))*t)+.027*Math.sin(TAU*269*t));}
  let steps=0;
  if(t<7.8||t>27.5)for(let at=Math.floor(t*2.1)/2.1-.48;at<t+.1;at+=.47619)steps+=beat(t,at)*.15;
  const alert=bell(t,14.3,523.25)*.13+bell(t,15.7,659.25)*.11;
  const catchSound=bell(t,24.05,783.99)*.23+bell(t,24.17,1046.5)*.15+beat(t,24.07)*.16;
  const ending=bell(t,32.35,392)*.08+bell(t,32.6,523.25)*.08;
  const calm=(bed+wind+leaves)*(t>=13&&t<19?.5:1);
  const m=calm+birds+drone+steps+alert+catchSound+ending;
  const l=Math.tanh(m+.028*Math.sin(TAU*220*t));
  const r=Math.tanh(m-.028*Math.sin(TAU*220*t)+leaves*.2);
  buf.writeInt16LE(Math.round(l*23500),44+i*4);
  buf.writeInt16LE(Math.round(r*23500),46+i*4);
 }
 await fs.writeFile(file,buf);
 return {sampleRate:SR,channels:2,seconds:SECONDS,bytes:buf.length};
}
